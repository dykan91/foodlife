<?php
// Text
$_['text_option_out_stock']	= 'Нет в наличии';
$_['text_name'] 			= 'Название: ';
$_['text_price'] 			= 'Цена: ';
$_['text_quantity'] 		= 'Количество: ';
$_['text_short_quantity'] 	= ' шт.';
$_['text_sku'] 	   			= 'Артикул: ';
$_['text_points'] 	   		= 'Цена в баллах: ';
$_['text_weight'] 	   		= 'Вес: ';