<?php
// Heading
$_['heading_title'] = 'Информация';

// Text
$_['text_contact']  = 'Связаться с нами';
$_['text_sitemap']  = 'Карта сайта';

