<?php
// Text
$_['text_option_out_stock']	= 'Out of stock';
$_['text_name'] 			= 'Name: ';
$_['text_price'] 			= 'Price: ';
$_['text_quantity'] 		= 'Quantity: ';
$_['text_short_quantity'] 	= ' pieces';
$_['text_sku'] 	   			= 'Sku: ';
$_['text_points'] 	   		= 'Price in points: ';
$_['text_weight'] 	   		= 'Weight: ';