<?php
// Text
$_['text_title'] = 'Бесплатный заказ';
