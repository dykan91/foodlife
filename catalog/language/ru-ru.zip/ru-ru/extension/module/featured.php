<?php
// Heading
$_['heading_title'] = 'Рекомендуемые';

// Text
$_['text_tax']      = 'Без НДС:';

