<?php
// Heading
$_['heading_title']    = 'Аналитика';

// Text
$_['text_success']     = 'Настройки успешно изменены!';
$_['text_list']        = 'Список модулей';

// Column
$_['column_name']      = 'Название';
$_['column_status']    = 'Статус';
$_['column_action']    = 'Действие';

// Error
$_['error_permission'] = 'У Вас нет прав для редактирования расширения Аналитика!';

